﻿using System;

namespace Problema02
{
    public class Program
    {
        static void Main(string[] args)
        {
            var valorRetorno = GetRetorno(Console.ReadLine()).Split('|');

            Console.WriteLine("Los '" + valorRetorno[0] + "' Números primos a partir de " + valorRetorno[1] + ".");
            Console.ReadLine();
        }
        public static string GetRetorno(string datos)
        {
            string valorRetorno = string.Empty;
            string[] inputs = datos.Split(',');
            int x = int.Parse(inputs[0]);
            var n = int.Parse(inputs[1]);
            for (int i = x; i <= n; i++)
            {
                if (IsPrime(i))
                {
                    valorRetorno += i + " ";
                }
            }

            return valorRetorno.Trim() + "|" + x;
        }
        private static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            if (number == 2) return true;
            if (number % 2 == 0) return false;

            var boundary = (int)Math.Floor(Math.Sqrt(number));

            for (int i = 3; i <= boundary; i += 2)
                if (number % i == 0)
                    return false;

            return true;
        }
    }
}
