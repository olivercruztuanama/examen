﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion04
{
    /// <summary>
    /// Factory method | Sección 5. PATRONES.
    /// </summary>
    public class Parametros
    {
        public string ParametroRequest { get; set; }
        public string ParametroResponse { get; set; }
        public string Usuario { get; set; }
        public string FechaRequest { get; set; }
        public string FechaResponse { get; set; }
    }
}
