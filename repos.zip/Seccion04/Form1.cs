﻿using Microsoft.VisualStudio.TestPlatform.ObjectModel.DataCollection;
using Newtonsoft.Json;
using System;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seccion04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnGenerar_Click(object sender, EventArgs e)
        {
            var sessionId = new SessionId();
            string api = "problema02";
            var request = JsonConvert.SerializeObject(new Parametros()
            {
                Usuario = sessionId.Id.ToString(),
                ParametroRequest = txtNro.Value + "," + txtCantidad.Value,
                FechaRequest = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                FechaResponse = null
            });

            // Execute Api call Async
            var httpResponseMessage = await MakeApiCall(api, request);

            // Execute Api call Async
            var result = await FetchResult<Parametros>(httpResponseMessage);

            MessageBox.Show("Los " + result.ParametroResponse + " Números primos a partir de " + txtNro.Value);
        }

        private async Task<HttpResponseMessage> MakeApiCall(string api, string request)
        {
            string host = ConfigurationManager.AppSettings["urlapi"];

            using (var handler = new HttpClientHandler { UseCookies = false })
            {
                var client2 = new HttpClient(handler);
                var requestData = new HttpRequestMessage(HttpMethod.Get, host + api);
                if (request != string.Empty)
                {
                    requestData.Content = new StringContent(request, Encoding.UTF8, "application/json");
                }

                client2.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var result = await client2.SendAsync(requestData);

                return result;
            }
        }
        public async Task<T> FetchResult<T>(HttpResponseMessage result)
        {
            if (result.IsSuccessStatusCode)
            {
                // Convert the HttpResponseMessage to string
                var resultArray = await result.Content.ReadAsStringAsync();

                // Json.Net Deserialization
                var final = JsonConvert.DeserializeObject<T>(resultArray);

                return final;
            }
            return default(T);
        }
    }
}