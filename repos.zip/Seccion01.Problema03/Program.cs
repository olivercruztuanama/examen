﻿using System;
using System.Linq;

namespace Problema03
{
    class Program
    {
        static void Main(string[] args)
        {
            string ojos, cejas, nariz, boca, cabello, orejas, cara, menton = string.Empty;
            while (true)
            {
                Console.WriteLine("Un caracter para los ojos: ");
                ojos = Console.ReadLine();
                var ojos_ = ojos.IndexOf("O");
                if (ojos_ < 0)
                {
                    ojos_ = ojos.IndexOf("o");
                    if (ojos_ < 0) { Console.WriteLine("El caracter '" + ojos + "' ingresado es incorrecto"); }
                    else { ojos = "< o o >"; break; }
                }
                else { ojos = "< O O >"; break; }
            }

            while (true)
            {
                Console.WriteLine("Dos caracteres para las cejas, pueden ser repetidos: ");
                cejas = Console.ReadLine();
                var cejas_ = cejas.Replace(" ", "").IndexOf("--");
                if (cejas_ < 0)
                {
                    cejas_ = cejas.IndexOf("- -");
                    if (cejas_ < 0) { Console.WriteLine("El caracter '" + cejas + "' ingresado es incorrecto"); }
                    else { cejas = "! _ _ !"; break; }
                }
                else { cejas = "! _ _ !"; break; }
            }

            while (true)
            {
                Console.WriteLine("Un caracter para la nariz: ");
                nariz = Console.ReadLine();
                var nariz_ = nariz.IndexOf("v");
                if (nariz_ < 0)
                {
                    nariz_ = nariz.IndexOf("V");
                    if (nariz_ < 0) { Console.WriteLine("El caracter '" + nariz + "' ingresado es incorrecto"); }
                    else { nariz = "!  v  !"; break; }
                }
                else { nariz = "!  v  !"; break; }
            }

            while (true)
            {
                Console.WriteLine("Tres caracteres para la boca en el orden que se quiere que aparezcan: ");
                boca = Console.ReadLine();
                var boca_ = boca.IndexOf(@"\_/");
                if (boca_ < 0)
                {
                    boca_ = boca.IndexOf("___");
                    if (boca_ < 0) { Console.WriteLine("El caracter '" + boca + "' ingresado es incorrecto"); }
                    else { boca = @"! \_/ !"; break; }
                }
                else { boca = @"! \_/ !"; break; }
            }

            while (true)
            {
                Console.WriteLine("Un caracter para el Cabello: ");
                cabello = Console.ReadLine();
                var cabello_ = cabello.IndexOf("$");
                if (cabello_ < 0)
                {
                    Console.WriteLine("El caracter '" + cabello + "' ingresado es incorrecto");
                }
                else { cabello = " $$$$$"; break; }
            }

            while (true)
            {
                Console.WriteLine("Dos caracteres para las orejas: ");
                orejas = Console.ReadLine();
                var orejas_ = orejas.Replace(" ","").IndexOf("<>");
                if (orejas_ < 0)
                {
                    Console.WriteLine("El caracter '" + orejas + "' ingresado es incorrecto");
                }
                else { break; }
            }

            while (true)
            {
                Console.WriteLine("Un caracter para delinear la cara o para el contorno: ");
                cara = Console.ReadLine();
                var cara_ = cara.IndexOf("!");
                if (cara_ < 0)
                {
                    Console.WriteLine("El caracter '" + cara + "' ingresado es incorrecto");
                }
                else { cara = " !   !"; break; }
            }

            while (true)
            {
                Console.WriteLine("Tres caracteres para el mentón: ");
                menton = Console.ReadLine();
                var menton_ = menton.IndexOf(@"\_/");
                if (menton_ < 0)
                {
                    menton_ = menton.IndexOf("___");
                    if (menton_ < 0) { Console.WriteLine("El caracter '" + menton + "' ingresado es incorrecto"); }
                    else { menton = @"  \_/   "; break; }
                }
                else { menton = @"  \_/   "; break; }
            }

            imprimir("\n");
            imprimir(cabello);
            imprimir(cejas);
            imprimir(ojos);
            imprimir(nariz);
            imprimir(boca);
            imprimir(cara);
            imprimir(menton);
            Console.ReadLine();
        }

        private static void imprimir(string data)
        {
            Console.WriteLine(data);
        }
    }
}