﻿using Microsoft.AspNetCore.Mvc;
using Seccion02.Models;
using System;
using System.Threading.Tasks;
using Seccion02.Contexts;

namespace Seccion02.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class Problema02Controller : Controller
    {
        private readonly Repository _repository;
        public Problema02Controller(Repository repository)
        {
            this._repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromBody] Parametros obj)
        {
            string[] inputs;
            inputs = obj.ParametroRequest.Split(',');
            int x = int.Parse(inputs[0]);
            var n = int.Parse(inputs[1]);
            for (int i = x; i <= n; i++)
            {
                if (IsPrime(i))
                {
                    obj.ParametroResponse += i + " ";
                }
            }
            obj.ParametroResponse = obj.ParametroResponse.Trim();

            //Caso Seccion 3: PERSISTENCIA.
            obj.FechaResponse = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            var response = await _repository.Auditoria(obj);

            return Ok(obj);
        }

        private static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            if (number == 2) return true;
            if (number % 2 == 0) return false;

            var boundary = (int)Math.Floor(Math.Sqrt(number));

            for (int i = 3; i <= boundary; i += 2)
                if (number % i == 0)
                    return false;

            return true;
        }
    }
}
