﻿using Microsoft.Extensions.Configuration;
using Seccion02.Models;
using System;
using System.Data.SqlClient;
using System.Threading.Tasks;

/// <summary>
/// Seccion 3: PERSISTENCIA
/// </summary>
namespace Seccion02.Contexts
{
    /// <summary>
    /// PATRON
    /// </summary>
    public class Repository
    {
        private static string _connectionString;
        public Repository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("ConnectionString");
        }

        public async Task<Parametros> Auditoria(Parametros obj)
        {
            var response = new Parametros();
            string query = string.Empty;
            query += "insert into auditoria values('" + obj.ParametroRequest + "','" + obj.FechaRequest + "','" +
                obj.ParametroResponse + "','" + obj.FechaResponse + "','" + obj.Usuario + "');";

            using (var sql = new SqlConnection(_connectionString))
            {
                using (var cmd = new SqlCommand(query, sql))
                {
                    try
                    {
                        await sql.OpenAsync();
                        await cmd.ExecuteNonQueryAsync();
                        cmd.Dispose();
                    }
                    catch (Exception ex)
                    {
                        response.ParametroResponse = ex.Message;
                    }
                    finally { sql.Close(); }
                }
            }

            return obj;
        }
    }
}